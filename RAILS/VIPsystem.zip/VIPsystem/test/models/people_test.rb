require 'test_helper'

class PeopleTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
